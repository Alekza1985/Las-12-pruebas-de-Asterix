1. Crea la composición que se ve en la foto adjunta (composicion).
2. La cuerda floja debe ser creada con CANVAS.
3. Cuando se haga click en el césped izquierdo, Asterix debe moverse hacia atrás, cuando se haga click en el derecho hacia adelante.
4. si se hace click fuera del césped, Asterix cae en el foso de los cocodrilos.