const canvas = document.getElementById("cuerda");
const context = canvas.getContext("2d");
let offsetX = 0; // Cantidad a desplazar hacia la derecha
let offsetY = 0; // Cantidad a desplazar hacia la derecha



// Dibujar una línea con una ligera curvatura girada 180 grados
context.beginPath();
context.lineWidth = "10";
context.strokeStyle = "#000";
context.moveTo(50 + offsetX, 50  + offsetY); // Punto de inicio de la línea

// Definir las coordenadas del punto de control y el punto final de la línea curva
const controlX = 500 + offsetX; // Coordenada X del punto de control
const controlY = 85 + offsetY; // Coordenada Y del punto de control
const endPointX = 950 + offsetX; // Coordenada X del punto final
const endPointY = 40  + offsetY; // Coordenada Y del punto final

context.quadraticCurveTo(controlX, controlY, endPointX, endPointY);
context.stroke();



const asterixposterright = document.querySelector(".rightbuttongreen");
const asterixposterleft = document.querySelector(".leftbuttongreen");
const svgElement = document.querySelector(".precipicio");
const asterix = document.querySelector(".asterix");

let positionLeft = 0; // Inicializa la posición izquierda
let positionDown = 0; // Inicializa la posición hacia abajo


asterixposterleft.addEventListener('click', moverIzquierda);
asterixposterright.addEventListener('click', moverDerecha);

asterixposterleft.addEventListener('click', function(event) {
    moverIzquierda();
    event.stopPropagation(); // Evita la propagación del clic al documento
});

asterixposterright.addEventListener('click', function(event) {
    moverDerecha();
    event.stopPropagation(); // Evita la propagación del clic al documento
});


function moverIzquierda() {
    if (positionLeft - 10 >= 0) {
        positionLeft -= 10;
        asterix.style.left = `${positionLeft}px`;
        asterix.style.transform = 'scaleX(-1) translateY(-5rem)';
    } else {
        asterixCae();
    }
}

function moverDerecha() {
    const viewportWidth = window.innerWidth;
    if (positionLeft + 10 <= viewportWidth) {
        positionLeft += 10;
        asterix.style.left = `${positionLeft}px`;
        asterix.style.transform = 'scaleY(1) translateY(-5rem)';
    } else {
        asterixCae();
    }
}

    // Función para mover la imagen hacia 
    function asterixCae() {
      asterix.style.transform = 'translateY(290px)';
    
    }

    // Agregar un event listener para detectar clics en cualquier parte de la pantalla
    document.addEventListener('click', asterixCae);




