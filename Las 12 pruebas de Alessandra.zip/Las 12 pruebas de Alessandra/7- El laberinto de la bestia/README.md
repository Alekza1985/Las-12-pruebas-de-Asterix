1. Crea el laberinto que se observa en la foto adjunta utilzando únicamente clases atómicas y elementos tipo span.
2. Crea una función en JS que calcule el número de elementos span utilizados para hacer la prueba.
3. Crea un botón que muestre debajo del laberinto el nmúmero de spans usados para construirlo.