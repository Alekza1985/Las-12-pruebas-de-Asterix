1. Crea una carta de restaurante con todos los platos de la película. (El elefante asado, el buey, etc...).
2. La carta deberá mostrar:
    - Un título con fuente tipo handwriting: La cocina de Manekkenpix.
    - Un listado vertical con todos los platos y cada item deberá mostrar: una foto del plato (el animal en su defecto), el título del plato el precio y descriupción breve (como en la foto).

3. La carta deberá añadir nuevos platos (los mismos, que se irán repitiendo) hasta el infinito al hacer scroll.

4. No olvides darle su galletita de postre a Obelix (grabar una cookie).

https://www.youtube.com/watch?v=4q8QyvBYh5E
