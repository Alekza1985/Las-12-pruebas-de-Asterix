function scrollInfinite() {
    // Verifico si si se ha llegado al final de la página
    const isAtBottom = (window.scrollY + window.innerHeight >= document.body.scrollHeight);

    // Si se ha llegado al final, se ejecuta la función scrollToTop()
    if (isAtBottom) {
        scrollToTop();
    }
}

function scrollToTop() {
    // Desplazamiento hacia arriba por la altura de la ventana visible
    window.scrollBy({
        top: -window.innerHeight
    });
}

// Agrego un listener para el evento de scroll, que llama a scrollInfinite() cuando se produce el scroll
window.addEventListener('scroll', scrollInfinite);
