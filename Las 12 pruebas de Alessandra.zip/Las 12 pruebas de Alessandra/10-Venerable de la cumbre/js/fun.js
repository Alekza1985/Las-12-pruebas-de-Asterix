const btn = document.querySelector('button');

const niveles = [
  document.querySelector('.five__level'),
  document.querySelector('.four__level'),
  document.querySelector('.third__level'),
  document.querySelector('.second__level'),
  document.querySelector('.first__level')
];

let nivelActual = 0;

btn.addEventListener('click', () => {
  if (nivelActual < niveles.length) {
    niveles[nivelActual].style.visibility = 'visible';
    nivelActual++;
  }

  
});

