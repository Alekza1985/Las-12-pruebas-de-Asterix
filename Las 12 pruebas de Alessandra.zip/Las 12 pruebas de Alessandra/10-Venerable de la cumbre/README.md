1. Crea la montaña que se ve en el video.
2. La montaña se debe crear paso por paso cada vez que hagas click en el botón " construir montaña"
3. En el último paso deberá aparecer el venerable de la cumbre y las nieves imperecederas del olimpo.

