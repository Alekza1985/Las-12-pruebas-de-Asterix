const btn = document.querySelector('.lanzamiento__button');
const mapamundi = document.querySelector('.mapamundi__container');
const circle = document.querySelector('.circle');
const gameover = document.querySelector('.gameover');


let lanzamientos = 0;

btn.addEventListener('click', function () {
    if (lanzamientos < 10) {
      const randomX = Math.random() * window.innerWidth;
      const randomY = Math.random() * window.innerHeight;

      circle.style.left = `${randomX}px`;
      circle.style.top = `${randomY}px`;
      circle.style.display = 'flex';

      lanzamientos++;
    }

    if (lanzamientos >= 10) {
        mapamundi.style.backgroundColor= "black";        
        gameover.style.display= "flex";
        circle.style.display= "none";
    }
  });

 