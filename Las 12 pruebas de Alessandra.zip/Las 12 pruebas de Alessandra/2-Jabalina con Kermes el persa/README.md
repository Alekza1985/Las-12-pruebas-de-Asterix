1.  CRea un layout que muestre en mapamundi con la foto de kermes en una esquina.

2. Crea un botón que lance la jabalina en un punto aleatorio del planeta (punto rojo).

3. el punto rojo desaparece con cada nuevo lanzamiento.

4. El juego termina después de 10 lanzamientos mostrando un rótulo que diga "juego terminado" en el centro de la pantalla.