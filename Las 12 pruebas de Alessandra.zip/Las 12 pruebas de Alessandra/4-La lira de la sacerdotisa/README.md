1. Haz que suene la lira de Asuranceturix con las notas: do, re, fa, sol, la cuando se toca en cada cuerda.

2. Haz que se pueda toca repetidamente las notas de cada cuerda.

3. Está permitido modificar el SVG o crear uno nuevo.
