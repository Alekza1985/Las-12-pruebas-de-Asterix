document.addEventListener('DOMContentLoaded', function() {
    // Obtener referencias a los elementos de las cuerdas y los sonidos
    const cuerdas = document.querySelectorAll('.cuerda');
    
    // Función para reproducir sonido al hacer clic en cualquier parte del documento
    document.addEventListener('click', function() {
      cuerdas.forEach((cuerda) => {
        cuerda.addEventListener('mouseover', function (e) {
          const soundId = this.getAttribute('data-sound');
          const sound = document.getElementById(soundId);
          
          if (sound) {
            sound.currentTime = 0; // Reiniciar el sonido si ya está en reproducción
            sound.play();
          }
        });
      });
    }, { once: true }); // El evento click se ejecutará solo una vez después de la carga
  });
  