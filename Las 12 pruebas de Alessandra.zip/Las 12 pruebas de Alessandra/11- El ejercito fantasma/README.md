1. Crea un grid simétrico de 6x6 en el que aparezcan aleatoriamente fantasmas y desaparezcan rápidamente.
3. Implementa un juego: cuando el usuario consiga hacer click en un fantasma muestra un rótulo "WIN"
4. Cuando pasen 5 segundos el juego termina y s e muestra un rótulo " GAME OVER".
5. Utiliza el método requestAnimationFrame()
7. el grid debe ser responsive y nunca perder la simetría.

request animation frame

