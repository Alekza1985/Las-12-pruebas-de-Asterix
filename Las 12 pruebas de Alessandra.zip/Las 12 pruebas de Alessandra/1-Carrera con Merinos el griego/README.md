1. Crea un sistema en js que detecte el número de clicks que haga el ratón sobre el botón de la foto adjunta en 3 segundos.

2. Se deben hacer más de 20 clicks para pasar la prueba.

3. La barra de velocidad irá subiendo con cada click -> con 20 clicks sube hasta el tope.

4. Si se logra, cambiará la foto cuando pasen los 3 segundos a la foto "end".