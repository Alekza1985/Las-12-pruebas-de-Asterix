1. Crea un layout con la foto de Iris el egipcio adjunta en el centro exacto de la pantalla.

2. Crea un botón justo debajo que haga lo siguiente:
    - Los ojos de Iris brillar con una animación CSS con box-shadow/filter.

    - Aparecer un "bocadillo" tipo comic con la famosa frase del vidente egipcio.

3. Todos los elementos deben estar estilados con gusto y emulando la estética de un comic.