const btn = document.querySelector('button');
const bubble = document.querySelector('.speech__bubble');
const rightEye = document.querySelector('.right-eye');
const leftEye = document.querySelector('.left-eye');

let contador = 0;

btn.addEventListener("click", function() {
    if (contador === 0) {
        bubble.style.display = "flex";
        rightEye.style.display = "flex";
        leftEye.style.display = "flex";
        contador = 1;
    } else {
        bubble.style.display = "none";
        rightEye.style.display = "none";
        leftEye.style.display = "none";
        contador = 0;
    }
});


  

