
const weaponsasterix = {
    p0: {
    name: 'puño ',
    force: '1'
    },
    p1: {
    name: 'pierna ',
    force: '2'
    }, 
    p2: {
    name: 'bofetada ',
    force: '3'
    },
    p3: {
    name: 'sentadilla ',
    force: '4'
    },
    p4: {
    name: 'poción ',
    force: 'null',
    },
    };

const weaponscilindrix = {
    p0: {
    name: 'llave ',
    force: '1'
    },
    p1: {
    name: 'luxación ',
    force: '2'
    }, 
    p2: {
    name: 'bofetada ',
    force: '3'
    },
    p3: {
    name: 'sentadilla ',
    force: '4'
    },
    };

    
    if (force = 'null') {
        force = '1'
    };


 
//Capturamos elementos

const btnFight = document.querySelector('.btn-fight'); //añado clase en el html al boton
const photoContainerCilindrix = document.querySelector('.game__fighter-left-in'); //añado clase 
const photoContainerAsterix = document.querySelector('.game__fighter-right-in'); //añado clase 

 
let forcetotalLeft = 0;
let forcetotalRight = 0;
let photoContainerLeft;  
let photoContainerRight;

btnFight.addEventListener('click', fight);

function fight(){

//primer resultado

//LEFT cilindrix
const keyLeft = Math.floor(Math.random()*4);//genero numero aleatorio entero entre 0 y 4
const weaponsleft=weaponscilindrix['p'+keyLeft].name
const weaponsleftDisplay = document.querySelector('.weapons__left-display');
weaponsleftDisplay.textContent = weaponsleft;

let forceLeft = weaponscilindrix['p'+keyLeft].force;


//RIGHT asterix

const keyRight = Math.floor(Math.random()*5); //genero saleatorio entre 0 y 5
const weaponsright=weaponsasterix['p'+keyRight].name
const weaponsrightDisplay = document.querySelector('.weapons__right-display');
weaponsrightDisplay.textContent = weaponsright;


let forceRight = weaponsasterix['p'+keyRight].force;

resultmatch(forceLeft,forceRight)


// Funcion que va calculando el resultado de cada partida
function resultmatch(forceLeft,forceRight){

    
    if (forceLeft > forceRight) {
        // Ganador Left  cilindrix
           forcetotalLeft = forcetotalLeft +1 ;
   
    
    } else if (forceRight > forceLeft) {
        // Ganador Right   asterix
           forcetotalRight= forcetotalRight +1;
           
    } else {
        // Empate
          forcetotalLeft= forcetotalLeft ;
          forcetotalRight= forcetotalRight ;
      
    }

    forceLeft=0;
    forceRight=0;


    const resultrightDisplay = document.querySelector('.result__right-display');
    resultrightDisplay.textContent = forcetotalRight;

    const resultleftDisplay = document.querySelector('.result__left-display');
    resultleftDisplay.textContent = forcetotalLeft;

    photoContainerCilindrix.parentNode.classList.remove ('winner', 'draw'); //aqui quito las clases siempre antes de que se apliquen de nuevo. 
        photoContainerAsterix.parentNode.classList.remove ('winner', 'draw');

    if (forcetotalLeft>=5 ||  forcetotalRight>=5 ){
  
        showWinner(forcetotalLeft, forcetotalRight)
        forcetotalLeft=0;
        forcetotalRight=0;
        forceLeft=0;
        forceRight=0;
    
        

        } 

        }

}


// Funcion que muestra al ganador del juego
function showWinner(forcetotalLeft, forcetotalRight) { //hay que definir las const de nuevo porque estaban en la funcion anterior. Y las funciones encapsulan las var y const, o sea que hay que nombrarlas nuevamente siempre

    photoContainerCilindrix.parentNode.classList.remove ('winner', 'draw'); //aqui quito las clases siempre antes de que se apliquen de nuevo. 
    photoContainerAsterix.parentNode.classList.remove ('winner', 'draw');


if (forcetotalLeft > forcetotalRight) {
    // Ganador Left 
    photoContainerCilindrix.parentNode.classList.add('winner');

 

} else if (forcetotalRight > forcetotalLeft) {
    // Ganador Right
    photoContainerAsterix.parentNode.classList.add('winner');
   
    
} else {
    // Empate
    photoContainerCilindrix.parentNode.classList.add('draw');
    photoContainerAsterix.parentNode.classList.add('draw');
  
}




}

 